<?php
    class Foo {
        public function doSomething()
        {
            $i = 5; // Unused
        }
    }
    echo "sd \n";

?>
